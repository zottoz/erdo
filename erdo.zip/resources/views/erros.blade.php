@extends('adminlte::page')

@section('content')

    {{ $saida }}

@stop