@extends('adminlte::page')

@section('content')

<h2>
    index de Usuarios
</h2>


@stop