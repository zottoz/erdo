@extends('adminlte::page')

@section('content')

<h2>
    Configuração de Usuário
</h2>


@stop