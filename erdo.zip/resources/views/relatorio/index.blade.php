@extends('adminlte::page')

@section('content')

<h2>
    Relatórios
</h2>


@stop